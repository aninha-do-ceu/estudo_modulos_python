class Calculadora:

    def print_hi(name):
        # Use a breakpoint in the code line below to debug your script.
        print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.

    def soma(a, b):
        print(a + b)

# if __name__ == '__main__':
#     a = Calculadora
#     a.print_hi('Ana')
#     a.soma(3,6)